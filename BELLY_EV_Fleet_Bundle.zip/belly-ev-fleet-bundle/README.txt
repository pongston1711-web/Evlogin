# BELLY Engineering — EV Fleet & Charging Control

ไฟล์ในแพ็กเกจนี้:

- index.html          → แอปหลัก (Dashboard, บันทึก, Export Excel ฟอร์มใหม่)
- login.html          → เข้าสู่ระบบ + จัดการผู้ใช้ (Admin)
- forms/              → ฟอร์ม Excel ตัวอย่าง พ.ย. 2026
- cloudflare-worker/  → Worker + KV sync (ดู README.md ภายใน)

เริ่มต้นเร็ว:
1. เปิด login.html / index.html บนเว็บเซิร์ฟเวอร์หรือ Cloudflare Pages
2. (ถ้าต้องการซิงค์คลาวด์) ทำตาม cloudflare-worker/README.md
3. แก้ API_BASE ใน index.html เป็น URL Worker จริง

© 2026 BELLY ENGINEERING
