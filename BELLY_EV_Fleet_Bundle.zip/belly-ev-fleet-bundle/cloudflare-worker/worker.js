/**
 * BELLY Engineering — EV Fleet & Charging Control
 * Cloudflare Worker + KV sync
 *
 * Endpoints:
 *   GET  /api/data  → { plate, department, rows, updatedAt }
 *   PUT  /api/data  → body { plate, department, rows, updatedBy }
 *                     → { ok: true, updatedAt }
 *   GET  /api/health → { ok: true, service, time }
 *
 * Bindings (wrangler.toml):
 *   EV_FLEET_KV  — KV namespace
 *   Optional env:
 *     API_KEY     — ถ้าตั้งค่า ต้องส่ง header X-API-Key ตรงกัน
 *     ALLOWED_ORIGIN — CORS origin (default *)
 */

const DATA_KEY = 'belly_ev_fleet_v1';

const corsHeaders = (origin) => ({
  'Access-Control-Allow-Origin': origin || '*',
  'Access-Control-Allow-Methods': 'GET, PUT, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-API-Key',
  'Access-Control-Max-Age': '86400',
});

function json(data, status = 200, origin = '*') {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      ...corsHeaders(origin),
    },
  });
}

function checkApiKey(request, env) {
  if (!env.API_KEY) return true; // ไม่บังคับถ้าไม่ได้ตั้ง
  const key = request.headers.get('X-API-Key') || '';
  return key === env.API_KEY;
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const origin = env.ALLOWED_ORIGIN || '*';
    const path = url.pathname.replace(/\/+$/, '') || '/';

    // CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: corsHeaders(origin),
      });
    }

    // Health
    if (path === '/api/health' || path === '/health') {
      return json({
        ok: true,
        service: 'BELLY EV Fleet API',
        time: new Date().toISOString(),
      }, 200, origin);
    }

    // Data API
    if (path === '/api/data') {
      if (!checkApiKey(request, env)) {
        return json({ error: 'Unauthorized' }, 401, origin);
      }

      if (request.method === 'GET') {
        try {
          const raw = await env.EV_FLEET_KV.get(DATA_KEY, { type: 'json' });
          if (!raw) {
            return json({
              plate: '',
              department: '',
              rows: [],
              updatedAt: null,
            }, 200, origin);
          }
          return json({
            plate: raw.plate || '',
            department: raw.department || '',
            rows: Array.isArray(raw.rows) ? raw.rows : [],
            updatedAt: raw.updatedAt || null,
            updatedBy: raw.updatedBy || null,
          }, 200, origin);
        } catch (e) {
          return json({ error: 'KV read failed: ' + e.message }, 500, origin);
        }
      }

      if (request.method === 'PUT') {
        try {
          let body;
          try {
            body = await request.json();
          } catch {
            return json({ error: 'Invalid JSON body' }, 400, origin);
          }

          if (!Array.isArray(body.rows)) {
            return json({ error: 'body.rows must be an array' }, 400, origin);
          }

          // จำกัดขนาดข้อมูล crudely (ป้องกัน payload ใหญ่เกินไป)
          const approx = JSON.stringify(body).length;
          if (approx > 2_500_000) {
            return json({ error: 'Payload too large (max ~2.5MB)' }, 413, origin);
          }

          const updatedAt = new Date().toISOString();
          const record = {
            plate: String(body.plate || ''),
            department: String(body.department || ''),
            rows: body.rows,
            updatedAt,
            updatedBy: String(body.updatedBy || '').slice(0, 80),
          };

          await env.EV_FLEET_KV.put(DATA_KEY, JSON.stringify(record));

          return json({ ok: true, updatedAt }, 200, origin);
        } catch (e) {
          return json({ error: 'KV write failed: ' + e.message }, 500, origin);
        }
      }

      return json({ error: 'Method not allowed' }, 405, origin);
    }

    // Root info
    if (path === '/' || path === '') {
      return json({
        service: 'BELLY EV Fleet & Charging Control API',
        version: 1,
        endpoints: ['GET /api/data', 'PUT /api/data', 'GET /api/health'],
      }, 200, origin);
    }

    return json({ error: 'Not found' }, 404, origin);
  },
};
