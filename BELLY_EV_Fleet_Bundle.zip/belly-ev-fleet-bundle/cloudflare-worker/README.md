# BELLY EV Fleet — Cloudflare Worker + KV

ซิงค์ข้อมูลรายการใช้รถ/ชาร์จ EV ระหว่างเครื่องผ่าน Cloudflare KV

## สิ่งที่ต้องมี

- บัญชี [Cloudflare](https://dash.cloudflare.com)
- Node.js 18+
- `npm i -g wrangler` หรือใช้ `npx wrangler`

## ติดตั้งครั้งแรก (ประมาณ 5 นาที)

```bash
cd cloudflare-worker

# 1) Login
npx wrangler login

# 2) สร้าง KV namespace
npx wrangler kv namespace create EV_FLEET_KV
# คัดลอก id ที่ได้ ไปใส่ใน wrangler.toml แทน REPLACE_WITH_YOUR_KV_NAMESPACE_ID

# (ถ้าต้องการ preview)
# npx wrangler kv namespace create EV_FLEET_KV --preview

# 3) Deploy
npx wrangler deploy
```

หลัง deploy จะได้ URL ประมาณ:

```
https://evbelly-api.<your-subdomain>.workers.dev
```

## เชื่อมกับแอป (index.html)

แก้บรรทัดนี้ใน `index.html`:

```js
const API_BASE = 'https://evbelly-api.YOUR_SUBDOMAIN.workers.dev';
```

เป็น URL จริงที่ได้จาก deploy เช่น:

```js
const API_BASE = 'https://evbelly-api.abc123.workers.dev';
```

จากนั้นอัปโหลด `index.html` + `login.html` ขึ้น hosting (Cloudflare Pages, R2, หรือที่อื่น)

## ทดสอบ

```bash
# Health
curl https://evbelly-api.xxx.workers.dev/api/health

# อ่านข้อมูล
curl https://evbelly-api.xxx.workers.dev/api/data

# เขียนทดสอบ
curl -X PUT https://evbelly-api.xxx.workers.dev/api/data \
  -H "Content-Type: application/json" \
  -d '{"plate":"7ขส.9454","department":"ผลิต / ผลิต6","rows":[],"updatedBy":"test"}'
```

## (แนะนำ) ใส่ API Key

```bash
npx wrangler secret put API_KEY
# พิมพ์รหัสลับ แล้ว Enter
```

แล้วแก้ฝั่ง client ให้ส่ง header:

```js
headers: {
  'Content-Type': 'application/json',
  'X-API-Key': 'รหัสเดียวกับที่ตั้งใน secret'
}
```

(ใน `pushToServer` และ `pullFromServer`)

## Deploy ซ้ำหลังแก้โค้ด

```bash
npx wrangler deploy
```

## โครงสร้างข้อมูลใน KV

Key: `belly_ev_fleet_v1`

```json
{
  "plate": "7ขส.9454",
  "department": "ผลิต / ผลิต6",
  "rows": [ /* รายการเดินทาง/ชาร์จ */ ],
  "updatedAt": "2026-11-24T01:00:00.000Z",
  "updatedBy": "Mozilla/5.0..."
}
```

## หมายเหตุ

- Worker นี้เป็น shared store ร่วมทั้งองค์กร (ทุกคนเห็นข้อมูลชุดเดียวกัน)
- ถ้าต้องการแยกตามโรงงาน/แผนก แก้ `DATA_KEY` หรือรับ `?site=` แล้วแยก key
- ขนาด KV value จำกัด ~25MB ต่อ key — แอปนี้จำกัด payload ฝั่ง Worker ที่ ~2.5MB
